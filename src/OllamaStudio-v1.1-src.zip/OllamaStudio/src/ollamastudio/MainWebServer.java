/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ollamastudio;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;




/**
 *
 * @author O.D.
 */
public class MainWebServer 
{

    // http://localhost:8000/
    
    public static void println(Object line)
    {
        System.out.println(line);        
    }
    
    public static class StudioHttpServer
    {
        public static void main() throws IOException 
        {
            // Create an HTTP server instance on port 8000
            int port = 8000;
            HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

            // Create a context for the root path "/" and set the handler
            server.createContext("/", new MyHandler());

            // Start the server
            server.setExecutor(null); // use the default executor
            server.start();

            println("Ollama Studio - server started on port 8000");
        }

        public static class MyHandler implements HttpHandler 
        {
            @Override
            public void handle(HttpExchange http) throws IOException 
            {
                String method = http.getRequestMethod();
                String context = http.getHttpContext().getPath();
                String host = http.getRequestURI().getHost();
                String app = http.getRequestURI().getPath();
                String query = http.getRequestURI().getQuery();
                
                if (app.equals("/favicon.ico"))
                    return;
                
                // println(host+" | "+method+" | "+context+" | "+app+" | "+query);
                /*
                => http://localhost:8000/
                    null | GET | / | / | null
                => http://localhost:8000/test?a=1&b=2
                    null | GET | / | /test | a=1&b=2
                => http://localhost:8000/work/test?a=1&b=2
                    null | GET | / | /work/test | a=1&b=2
                => http://localhost:8000/?a=1&b=2
                    null | GET | / | / | a=1&b=2
                */
                
                String url = http.getRequestURI().toString();
                // println(url);
                /*
                => http://localhost:8000/
                    /
                => http://localhost:8000/work/test?a=1&b=2
                    /work/test?a=1&b=2
                => http://localhost:8000/?a=1&b=2
                    /?a=1&b=2
                */
                
                if (url.equals("/favicon.ico"))
                    return;
                
                // => http://localhost:8000/hi
                if (url.equals("/hi"))
                {
                    String response = "Hi!";
                    http.sendResponseHeaders(200, response.length());
                    OutputStream os = http.getResponseBody();
                    os.write(response.getBytes());
                    os.close();                    
                    return;
                }
                
                
                if (method.equals("GET")) 
                {

                    try 
                    {
                        String tool = "research-tool.html";
                        
                        // Get the InputStream for the resource
                        InputStream inputStream = MainOllamaStudio.class.getClassLoader().getResourceAsStream(tool);

                        if (inputStream != null) 
                        {
                            // Read the content of the file
                            StringBuilder sb = new StringBuilder();
                            
                            try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) 
                            {
                                String line;
                                while ((line = reader.readLine()) != null) 
                                {
                                    sb.append(line);
                                    sb.append("\n");
                                }
                                
                                // Read the content of the file into a byte array
                                byte[] response = sb.toString().getBytes();

                                // Set the Content-Type header
                                http.getResponseHeaders().set("Content-Type", "text/html");

                                // Set the status code and response length
                                http.sendResponseHeaders(200, response.length);

                                // Write the file content to the response body
                                OutputStream os = http.getResponseBody();
                                os.write(response);
                                os.close();
                        
                            }
                        } 
                        else 
                        {
                            println("Ollama Studio - server resource error.");
                        }
                    } 
                    catch (IOException e) 
                    {
                        println("Ollama Studio - server request error.");
                    }
                } 
                else 
                {
                    // For any other request method, send a 405 Method Not Allowed error
                    http.sendResponseHeaders(405, -1);
                }
            }
        }    
    }

    
    public static void main(String[] args) throws IOException
    {
        StudioHttpServer.main();
    }
    
    
}
