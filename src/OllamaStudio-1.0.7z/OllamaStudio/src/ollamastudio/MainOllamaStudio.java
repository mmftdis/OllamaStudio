/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ollamastudio;

/**
 *
 * @author oferd
 */
public class MainOllamaStudio 
{

    public static void main(String[] args) 
    {
        try
        {
            MainWebServer.main(args);
            System.out.println("Open in browser: http://localhost:8000/");
        }
        catch(Exception e)
        {
            System.out.println("Ollama Studio - failed to start server !");
        }
    }
    
}
