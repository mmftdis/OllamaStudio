/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.llmtools.ollamastudio;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;




/**
 *
 * @author O.D.
 */
public class MainWebServer 
{

    // http://localhost:8000/
    
    
    public static class StudioHttpServer
    {
        public static void main() throws IOException 
        {
            // Create an HTTP server instance on port 8000
            HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);

            // Create a context for the root path "/" and set the handler
            server.createContext("/", new MyHandler());

            // Start the server
            server.setExecutor(null); // use the default executor
            server.start();

            System.out.println("Ollama Studio - server started on port 8000");
        }

        public static class MyHandler implements HttpHandler 
        {
            @Override
            public void handle(HttpExchange exchange) throws IOException 
            {
                if ("GET".equals(exchange.getRequestMethod())) 
                {

                    try 
                    {
                        // Get the InputStream for the resource
                        InputStream inputStream = OllamaStudio.class.getClassLoader().getResourceAsStream("js-terminal.html");

                        if (inputStream != null) 
                        {
                            // Read the content of the file
                            StringBuilder sb = new StringBuilder();
                            
                            try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) 
                            {
                                String line;
                                while ((line = reader.readLine()) != null) 
                                {
                                    sb.append(line);
                                    sb.append("\n");
                                }
                                
                                // Read the content of the file into a byte array
                                byte[] response = sb.toString().getBytes();

                                // Set the Content-Type header
                                exchange.getResponseHeaders().set("Content-Type", "text/html");

                                // Set the status code and response length
                                exchange.sendResponseHeaders(200, response.length);

                                // Write the file content to the response body
                                OutputStream os = exchange.getResponseBody();
                                os.write(response);
                                os.close();
                        
                            }
                        } 
                        else 
                        {
                            System.out.println("Ollama Studio - server resource error.");
                        }
                    } 
                    catch (IOException e) 
                    {
                        System.out.println("Ollama Studio - server request error.");
                    }
                } 
                else 
                {
                    // For any other request method, send a 405 Method Not Allowed error
                    exchange.sendResponseHeaders(405, -1);
                }
            }
        }    
    }

    
    public static void main(String[] args) throws IOException
    {
        StudioHttpServer.main();
    }
    
    
}
