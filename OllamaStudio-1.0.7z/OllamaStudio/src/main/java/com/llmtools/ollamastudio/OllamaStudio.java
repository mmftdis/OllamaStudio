
package com.llmtools.ollamastudio;

/**
 *
 * @author O.D.
 */
public class OllamaStudio 
{

    public static void main(String[] args) 
    {
        try
        {
            MainWebServer.main(args);
            System.out.println("Open in browser: http://localhost:8000/");
        }
        catch(Exception e)
        {
            System.out.println("Ollama Studio - failed to start server !");
        }
    }
    
}
